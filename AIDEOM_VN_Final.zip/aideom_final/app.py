"""
AIDEOM-VN — Mô hình ra quyết định phát triển kinh tế Việt Nam trong kỷ nguyên AI
12 bài tập tích hợp + tác nhân phân tích AI (Gemini)
"""

import streamlit as st
import numpy as np
import pandas as pd
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
from scipy.optimize import linprog, minimize
import requests, json, textwrap

# ──────────────────────────────────────────────────────────────────────────────
# PAGE CONFIG
# ──────────────────────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="AIDEOM-VN",
    page_icon="🇻🇳",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ──────────────────────────────────────────────────────────────────────────────
# GLOBAL CSS
# ──────────────────────────────────────────────────────────────────────────────
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');

html, body, [class*="css"] { font-family: 'Inter', sans-serif; }

/* Sidebar */
[data-testid="stSidebar"] {
    background: linear-gradient(180deg, #0d1b2a 0%, #1b2838 100%);
}
[data-testid="stSidebar"] * { color: #e8eaf6 !important; }
[data-testid="stSidebar"] .stRadio label { 
    font-size: 0.82rem; padding: 4px 0; 
}

/* Header bar */
.top-header {
    background: linear-gradient(90deg, #c8102e 0%, #1d3557 100%);
    color: white; padding: 16px 24px; border-radius: 10px;
    margin-bottom: 20px;
    display: flex; justify-content: space-between; align-items: center;
}
.top-header h1 { font-size: 1.7rem; font-weight: 700; margin: 0; color: white; }
.top-header p  { font-size: 0.85rem; margin: 4px 0 0; opacity: .85; color: white; }

/* Section titles */
.sec-title {
    font-size: 1.05rem; font-weight: 600; color: #1d3557;
    border-left: 4px solid #c8102e; padding-left: 10px;
    margin: 18px 0 10px;
}

/* Metric cards */
.kpi-row { display: flex; gap: 12px; margin-bottom: 16px; flex-wrap: wrap; }
.kpi-card {
    flex: 1; min-width: 130px;
    background: #f0f4ff; border-radius: 10px;
    padding: 12px 16px; border-top: 3px solid #c8102e;
}
.kpi-card .kpi-label { font-size: 0.72rem; color: #555; font-weight: 500; text-transform: uppercase; }
.kpi-card .kpi-value { font-size: 1.4rem; font-weight: 700; color: #1d3557; }
.kpi-card .kpi-delta { font-size: 0.75rem; color: #2a9d8f; margin-top: 2px; }

/* AI box */
.ai-box {
    background: linear-gradient(135deg, #f0f4ff 0%, #e8f5e9 100%);
    border: 1px solid #c8102e33; border-radius: 12px;
    padding: 16px 20px; margin-top: 20px;
}
.ai-box .ai-header {
    font-size: 0.8rem; font-weight: 700; color: #c8102e;
    text-transform: uppercase; letter-spacing: .06em; margin-bottom: 8px;
}
.ai-box .ai-content { font-size: 0.88rem; line-height: 1.65; color: #1d3557; }

/* Badge */
.badge {
    display: inline-block; padding: 2px 8px; border-radius: 20px;
    font-size: 0.7rem; font-weight: 600; margin-left: 6px; vertical-align: middle;
}
.b-easy   { background: #d4edda; color: #155724; }
.b-med    { background: #fff3cd; color: #856404; }
.b-hard   { background: #f8d7da; color: #721c24; }
.b-vhard  { background: #cce5ff; color: #004085; }

/* Tab styling */
.stTabs [data-baseweb="tab"] { font-size: 0.82rem; }

/* Formula box */
.formula {
    background: #1d3557; color: #a8dadc;
    border-radius: 8px; padding: 10px 16px;
    font-family: 'Courier New', monospace; font-size: 0.85rem;
    margin: 8px 0 14px;
}

/* Constraint list */
.constraint-list { background: #f8f9fa; border-radius: 8px; padding: 10px 14px; font-size: 0.82rem; }
</style>
""", unsafe_allow_html=True)

# ──────────────────────────────────────────────────────────────────────────────
# EMBEDDED DATA
# ──────────────────────────────────────────────────────────────────────────────
MACRO = pd.DataFrame({
    "year": [2020,2021,2022,2023,2024,2025],
    "GDP_trillion_VND": [8044.4,8487.5,9513.3,10221.8,11511.9,12847.6],
    "K_trillion_VND":   [16500,17800,19600,21300,23500,25900],
    "L_million":        [53.6,50.5,51.7,52.4,52.9,53.4],
    "D_digital_pct":    [12.0,12.7,14.3,16.5,18.3,19.5],
    "AI_tech_firms_thousand": [55.6,60.2,65.4,67.0,73.8,80.1],
    "H_trained_pct":    [24.1,26.1,26.2,27.0,28.4,29.2],
})

SECTORS = pd.DataFrame({
    "sector_id": range(1,11),
    "sector_name_vi": ["Nông-Lâm-Thủy sản","CN chế biến chế tạo","Xây dựng","Khai khoáng",
                        "Bán buôn-bán lẻ","Tài chính-Ngân hàng","Logistics-Vận tải",
                        "CNTT-Truyền thông","Giáo dục-Đào tạo","Y tế"],
    "growth_rate_2024_pct":               [3.27,9.64,7.45,-1.20,7.10,7.36,9.93,7.85,6.42,6.85],
    "productivity_million_VND_per_worker":[103.4,241.2,168.8,1290.5,145.3,1072.4,321.4,713.8,205.7,437.1],
    "spillover_coef_0_1": [0.35,0.78,0.42,0.30,0.55,0.85,0.72,0.92,0.65,0.60],
    "export_billion_USD": [40.5,290.9,2.5,8.2,5.5,1.2,3.1,178.0,0.0,0.0],
    "labor_million":      [13.20,11.50,4.80,0.30,7.80,0.55,1.95,0.62,2.15,0.75],
    "ai_readiness_0_100": [15,55,20,30,48,72,42,88,38,45],
    "automation_risk_pct":[18,42,25,55,38,52,35,28,22,18],
})

REGIONS = pd.DataFrame({
    "region_id": range(1,7),
    "region_name_vi": ["Trung du miền núi phía Bắc","Đồng bằng sông Hồng",
                        "Bắc Trung Bộ & DHMT","Tây Nguyên","Đông Nam Bộ","ĐBSCL"],
    "grdp_per_capita_million_VND": [57.0,152.3,87.5,68.9,158.9,80.5],
    "fdi_registered_billion_USD":  [3.5,20.0,8.2,0.8,18.5,2.1],
    "digital_index_0_100":  [38,78,55,32,82,48],
    "ai_readiness_0_100":   [22,68,40,18,75,30],
    "trained_labor_pct":    [21.5,36.8,27.5,18.2,42.5,16.8],
    "rd_intensity_pct":     [0.18,0.85,0.32,0.15,0.78,0.22],
    "internet_penetration_pct": [72,92,84,68,94,78],
    "gini_coef":            [0.405,0.358,0.372,0.412,0.385,0.392],
})

PROJ_NAME = {1:"TT Dữ liệu Hòa Lạc",2:"TT Dữ liệu phía Nam",3:"5G toàn quốc",
             4:"VNeID 2.0",5:"Cổng DVCQG v3",6:"Y tế số",7:"Giáo dục số K-12",
             8:"TT AI quốc gia",9:"Sandbox fintech",10:"Logistics thông minh",
             11:"Nông nghiệp số ĐBSCL",12:"Đào tạo 50K KS AI",13:"KCN bán dẫn",
             14:"An ninh mạng SOC",15:"Open Data quốc gia"}
PROJ_C  = {1:12000,2:11500,3:18000,4:4500,5:3200,6:5800,7:6500,8:15000,
           9:2500,10:7200,11:4800,12:8500,13:20000,14:3800,15:1500}
PROJ_C1 = {1:8500,2:7500,3:12000,4:3500,5:2500,6:4000,7:4500,8:9000,
           9:1800,10:5000,11:3500,12:5500,13:13000,14:2800,15:1200}
PROJ_B  = {1:21500,2:20800,3:32500,4:9200,5:6800,6:11400,7:12200,8:28500,
           9:5800,10:13800,11:8500,12:16200,13:35000,14:7500,15:3800}

VN_RED  = "#c8102e"
VN_GOLD = "#f0a500"
NAVY    = "#1d3557"
TEAL    = "#2a9d8f"
COLORS  = [VN_RED, NAVY, TEAL, VN_GOLD, "#457b9d", "#6d6875", "#e76f51", "#a8dadc"]

# ──────────────────────────────────────────────────────────────────────────────
# AI ANALYST  (Gemini via Google Generative Language API)
# ──────────────────────────────────────────────────────────────────────────────
def call_gemini(prompt: str, api_key: str) -> str:
    """Call Gemini 1.5 Flash and return text response."""
    url = (f"https://generativelanguage.googleapis.com/v1beta/models/"
           f"gemini-1.5-flash:generateContent?key={api_key}")
    payload = {"contents": [{"parts": [{"text": prompt}]}],
               "generationConfig": {"temperature": 0.4, "maxOutputTokens": 600}}
    try:
        r = requests.post(url, json=payload, timeout=20)
        r.raise_for_status()
        return r.json()["candidates"][0]["content"]["parts"][0]["text"]
    except Exception as e:
        return f"⚠️ Không kết nối được Gemini: {e}"

def ai_panel(title: str, context: str, api_key: str):
    """Render the AI analyst expandable panel."""
    with st.expander(f"🤖 Tác nhân AI phân tích — {title}", expanded=False):
        if not api_key:
            st.info("Nhập Gemini API key trong sidebar để kích hoạt phân tích tự động.")
            return
        sys_prompt = textwrap.dedent(f"""
            Bạn là chuyên gia kinh tế lượng và chính sách công Việt Nam.
            Phân tích ngắn gọn (200-300 từ, tiếng Việt) kết quả mô hình sau đây,
            tập trung vào ý nghĩa chính sách thực tiễn cho Việt Nam 2025-2030.
            Trình bày 3 điểm: (1) Nhận xét kết quả chính, (2) Khuyến nghị chính sách,
            (3) Hạn chế mô hình cần lưu ý.

            DỮ LIỆU / KẾT QUẢ:
            {context}
        """)
        if st.button(f"▶ Phân tích với Gemini AI", key=f"ai_{title}"):
            with st.spinner("Đang phân tích..."):
                result = call_gemini(sys_prompt, api_key)
            st.markdown(f'<div class="ai-box"><div class="ai-header">🤖 Gemini AI — Phân tích kết quả</div>'
                        f'<div class="ai-content">{result}</div></div>', unsafe_allow_html=True)

# ──────────────────────────────────────────────────────────────────────────────
# COMPUTATION HELPERS
# ──────────────────────────────────────────────────────────────────────────────
def compute_tfp(Y,K,L,D,AI,H, a=.33,b=.42,g=.10,d=.08,t=.07):
    return Y / (K**a * L**b * D**g * AI**d * H**t)

def forecast_gdp(A,K,L,D,AI,H, a=.33,b=.42,g=.10,d=.08,t=.07):
    return A*(K**a)*(L**b)*(D**g)*(AI**d)*(H**t)

def growth_decomp(df, a,b,g,d,t):
    Y,K,L,D_,AI,H = (df[c].values for c in
        ["GDP_trillion_VND","K_trillion_VND","L_million",
         "D_digital_pct","AI_tech_firms_thousand","H_trained_pct"])
    A = compute_tfp(Y,K,L,D_,AI,H,a,b,g,d,t)
    rows=[]
    for i in range(1,len(Y)):
        dY = np.log(Y[i])-np.log(Y[i-1])
        if dY==0: continue
        rows.append({"year":int(df.year.values[i]),
            "g_GDP_%": round(dY*100,2),
            "TFP": round((np.log(A[i])-np.log(A[i-1]))/dY*100,1),
            "K":   round(a*(np.log(K[i]) -np.log(K[i-1]))/dY*100,1),
            "L":   round(b*(np.log(L[i]) -np.log(L[i-1]))/dY*100,1),
            "D":   round(g*(np.log(D_[i])-np.log(D_[i-1]))/dY*100,1),
            "AI":  round(d*(np.log(AI[i])-np.log(AI[i-1]))/dY*100,1),
            "H":   round(t*(np.log(H[i]) -np.log(H[i-1]))/dY*100,1),
        })
    return pd.DataFrame(rows)

def lp_budget(B, mn1=25, mn2=15, mn3=20, mn4=10, strat=0.35):
    c   = [-0.85,-1.20,-0.95,-1.35]
    Aub = [[1,1,1,1],[-1,0,0,0],[0,-1,0,0],[0,0,-1,0],[0,0,0,-1],
           [strat,-(1-strat),strat,-(1-strat)]]
    bub = [B,-mn1,-mn2,-mn3,-mn4,0]
    res = linprog(c,A_ub=Aub,b_ub=bub,bounds=[(0,None)]*4,method="highs")
    return (res.x, -res.fun) if res.success else (np.array([mn1,mn2,mn3,mn4]),0.0)

def priority_index(df_s, w):
    cols=["growth_rate_2024_pct","productivity_million_VND_per_worker",
          "spillover_coef_0_1","export_billion_USD","labor_million",
          "ai_readiness_0_100","automation_risk_pct"]
    X = df_s[cols].values.astype(float)
    denom = np.sqrt((X**2).sum(0)); denom[denom==0]=1e-12
    Xn = X/denom
    Xn[:,6] = Xn[:,6].max()-Xn[:,6]
    return Xn @ np.array(w)

def topsis_calc(X, w, is_benefit):
    denom=np.sqrt((X**2).sum(0)); denom[denom==0]=1e-12
    R=X/denom; V=R*np.array(w)
    A_p=np.where(is_benefit,V.max(0),V.min(0))
    A_n=np.where(is_benefit,V.min(0),V.max(0))
    Sp=np.sqrt(((V-A_p)**2).sum(1)); Sn=np.sqrt(((V-A_n)**2).sum(1))
    return Sn/(Sp+Sn+1e-12)

def region_lp(budget, lam, fairness):
    beta=np.array([[1.15,0.85,0.55,1.30],[0.95,1.25,1.40,1.05],
                   [1.05,0.95,0.85,1.15],[1.20,0.75,0.45,1.35],
                   [0.90,1.30,1.55,1.00],[1.10,0.85,0.65,1.25]])
    D0=np.array([38.,78.,55.,32.,82.,48.]); g=0.002
    c=-beta.flatten(); Aub=[]; bub=[]
    Aub.append(np.ones(24)); bub.append(budget)
    for r in range(6):
        fl=np.zeros(24); cl=np.zeros(24)
        for j in range(4): fl[r*4+j]=-1; cl[r*4+j]=1
        Aub.append(fl); bub.append(-5000)
        Aub.append(cl); bub.append(12000)
    rowh=np.zeros(24)
    for r in range(6): rowh[r*4+3]=-1
    Aub.append(rowh); bub.append(-12000)
    if fairness:
        c2=np.append(c,0.); A2=[np.append(r,0.) for r in Aub]; b2=list(bub)
        for r in range(6):
            up=np.zeros(25); up[r*4+1]=g; up[24]=-1
            A2.append(up); b2.append(-D0[r])
            lo=np.zeros(25); lo[r*4+1]=-g*lam; lo[24]=lam
            A2.append(lo); b2.append(D0[r])
        res=linprog(c2,A_ub=A2,b_ub=b2,bounds=[(0,None)]*25,method="highs")
        if res.success: return res.x[:24].reshape(6,4),-res.fun
    res=linprog(c,A_ub=Aub,b_ub=bub,bounds=[(0,None)]*24,method="highs")
    return (res.x.reshape(6,4),-res.fun) if res.success else (np.zeros((6,4)),0.)

def mip_greedy(bt, b12):
    sel=[14,4,12]
    rb=bt-sum(PROJ_C[p] for p in sel); r12=b12-sum(PROJ_C1[p] for p in sel)
    cands=sorted([p for p in range(1,16) if p not in sel],
                  key=lambda p:-PROJ_B[p]/PROJ_C[p])
    for p in cands:
        if rb>=PROJ_C[p] and r12>=PROJ_C1[p] and len(sel)<11:
            sel.append(p); rb-=PROJ_C[p]; r12-=PROJ_C1[p]
    return sorted(sel), sum(PROJ_C[p] for p in sel), sum(PROJ_B[p] for p in sel)

def dynamic_opt(T=10, rho=0.97):
    K0,D0,AI0,H0,A0=27500,20.3,86,30,0.82
    L=np.linspace(53.9,55.0,T+1)
    def sim(x):
        I=x.reshape(T,4); K,D,AI,H,A=K0,D0,AI0,H0,A0; W=0
        Ks,Ds,AIs,Hs,GDPs=[K0],[D0],[AI0],[H0],[]
        for t in range(T):
            Y=A*(K**.33)*(L[t]**.42)*(D**.10)*(AI**.08)*(H**.07)
            GDPs.append(Y)
            C=max(Y-I[t].sum(),1.)
            W+=(rho**t)*np.log(C)
            K=(1-.05)*K+I[t,0]; D=(1-.12)*D+I[t,1]
            AI=(1-.15)*AI+I[t,2]; H=H+.8*I[t,3]-.02*H
            A=A*(1+.003*D+.002*AI+.004*H)
            Ks.append(K); Ds.append(D); AIs.append(AI); Hs.append(H)
        GDPs.append(A*(K**.33)*(L[T]**.42)*(D**.10)*(AI**.08)*(H**.07))
        return -W,np.array(Ks),np.array(Ds),np.array(AIs),np.array(Hs),np.array(GDPs)
    x0=np.ones(T*4)*300
    res=minimize(lambda x:sim(x)[0],x0,method="L-BFGS-B",
                 bounds=[(0,8000)]*T*4,options={"maxiter":200})
    _,K,D,AI,H,GDP=sim(res.x if res.success else x0)
    return K,D,AI,H,GDP

def labor_opt(budget):
    a1=np.array([8.5,32.5,12.8,22.4,45.8,28.5,62.5,18.5])
    b1=np.array([45.,28.,35.,32.,22.,30.,20.,55.])
    c1=np.array([5.2,62.4,18.5,48.2,72.5,42.8,32.5,12.5])
    d1=np.array([50.,32.,42.,38.,26.,36.,24.,62.])
    risk=np.array([18,42,25,38,52,35,28,22])/100; N=8
    c_obj=np.concatenate([-(a1-c1*risk),-b1])
    Aub=[np.ones(2*N)]; bub=[budget]
    for i in range(N):
        r=np.zeros(2*N); r[i]=-(a1[i]-c1[i]*risk[i]); r[N+i]=-b1[i]
        Aub.append(r); bub.append(0)
        r2=np.zeros(2*N); r2[i]=c1[i]*risk[i]; r2[N+i]=-d1[i]
        Aub.append(r2); bub.append(0)
    res=linprog(c_obj,A_ub=Aub,b_ub=bub,bounds=[(0,None)]*2*N,method="highs")
    if res.success:
        xAI,xH=res.x[:N],res.x[N:]
        return xAI,xH,(a1-c1*risk)*xAI+b1*xH
    return np.zeros(N),np.zeros(N),np.zeros(N)

def stoch_lp():
    scen={"Lạc quan":0.30,"Cơ sở":0.45,"Bi quan":0.20,"Khủng hoảng":0.05}
    bs={"Lạc quan":[1.25,1.35,1.55,1.05],"Cơ sở":[1.00,1.10,1.25,0.95],
        "Bi quan":[0.75,0.85,0.90,1.00],"Khủng hoảng":[0.40,0.50,0.55,1.10]}
    bb=[1.00,1.10,1.25,0.95]; ns=4; nj=4; nv=nj+ns*nj
    c=np.zeros(nv)
    for j in range(nj): c[j]=-bb[j]
    for si,(sn,ps) in enumerate(scen.items()):
        for j in range(nj): c[nj+si*nj+j]=-ps*bs[sn][j]
    Aub=[]; bub=[]
    row=np.zeros(nv); row[:nj]=1; Aub.append(row); bub.append(65000)
    for si in range(ns):
        row=np.zeros(nv); row[nj+si*nj:nj+(si+1)*nj]=1
        Aub.append(row); bub.append(15000)
    for si in range(ns):
        row=np.zeros(nv); row[nj+si*nj+2]=1; row[3]=-0.5
        Aub.append(row); bub.append(0)
    res=linprog(c,A_ub=Aub,b_ub=bub,bounds=[(0,None)]*nv,method="highs")
    if res.success:
        x=res.x[:nj]
        y={sn:res.x[nj+si*nj:nj+(si+1)*nj] for si,sn in enumerate(scen)}
        return x,y,-res.fun
    return np.zeros(nj),{},-0.

def q_train(eps_n=500, alpha=0.1, gamma=0.95):
    np.random.seed(42); Q=np.zeros((81,5))
    hist=[]
    def enc(ai,g,r,tr): return int(np.clip(ai,0,2))*27+int(np.clip(g,0,2))*9+int(np.clip(r,0,2))*3+int(np.clip(tr,0,2))
    def dec(s): ai=s//27;rem=s%27;g=rem//9;rem=rem%9;r=rem//3;tr=rem%3; return ai,g,r,tr
    def step(s,a):
        ai,g,r,tr=dec(s); rnd=np.random.rand
        if a==0:
            if rnd()<.7: g=min(2,g+1)
            if rnd()<.2: ai=max(0,ai-1)
        elif a==1:
            if rnd()<.8: ai=min(2,ai+1)
            if rnd()<.5: g=min(2,g+1)
            if tr<2:
                if rnd()<.8: r=min(2,r+1)
            else:
                if rnd()<.3: r=min(2,r+1)
        elif a==2:
            if rnd()<.8: tr=min(2,tr+1)
            if rnd()<.6: r=max(0,r-1)
            if rnd()<.4: ai=min(2,ai+1)
        elif a==3:
            if rnd()<.5: g=min(2,g+1)
            if rnd()<.4: ai=min(2,ai+1)
            if rnd()<.4: tr=min(2,tr+1)
            if rnd()<.3: r=max(0,r-1)
        else:
            if rnd()<.9: r=max(0,r-1)
            if rnd()<.5: tr=min(2,tr+1)
            if rnd()<.1: g=max(0,g-1)
        ns=enc(ai,g,r,tr)
        rew=([0,10,25][g]+[0,5,15][ai]+[0,5,12][tr]+[0,-8,-30][r]
             +{0:-4,1:-6,2:-5,3:-7,4:-3}[a]+(-20 if g==0 and r==2 else 0))
        return ns,rew
    eps=1.0
    for ep in range(eps_n):
        s=enc(1,1,1,1); tot=0; done=False; steps=0
        while not done:
            a=np.random.randint(5) if np.random.rand()<eps else int(np.argmax(Q[s]))
            ns,rw=step(s,a)
            Q[s,a]+=alpha*(rw+gamma*Q[ns].max()-Q[s,a])
            s=ns; tot+=rw; steps+=1; done=(steps>=20)
        eps=max(.05,eps*.995); hist.append(tot)
    return Q,hist

# ──────────────────────────────────────────────────────────────────────────────
# SIDEBAR
# ──────────────────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("## 🇻🇳 AIDEOM-VN")
    st.markdown("*Mô hình ra quyết định phát triển kinh tế Việt Nam trong kỷ nguyên AI*")
    st.divider()

    PAGES = {
        "🏠 Tổng quan": "overview",
        "📐 Bài 1 · Cobb-Douglas & TFP": "b01",
        "💰 Bài 2 · LP Phân bổ ngân sách": "b02",
        "📊 Bài 3 · Chỉ số ưu tiên ngành": "b03",
        "🗺️ Bài 4 · LP Phân bổ vùng miền": "b04",
        "🔲 Bài 5 · MIP Lựa chọn dự án": "b05",
        "🏆 Bài 6 · TOPSIS Xếp hạng vùng": "b06",
        "🌐 Bài 7 · Pareto đa mục tiêu": "b07",
        "⏱️ Bài 8 · Tối ưu động 2026-2035": "b08",
        "👷 Bài 9 · Thị trường lao động AI": "b09",
        "🎲 Bài 10 · Stochastic LP": "b10",
        "🤖 Bài 11 · Q-Learning chính sách": "b11",
        "🎛️ Bài 12 · Dashboard 5 kịch bản": "b12",
    }
    page = PAGES[st.radio("", list(PAGES.keys()), label_visibility="collapsed")]

    st.divider()
    st.markdown("#### 🔑 Gemini API Key")
    api_key = st.text_input("Nhập key để kích hoạt AI phân tích:",
                             type="password", placeholder="AIza...")
    if api_key:
        st.success("✅ AI analyst sẵn sàng")
    else:
        st.caption("Lấy key miễn phí: [aistudio.google.com](https://aistudio.google.com/app/apikey)")
    st.divider()
    st.caption("Dữ liệu: GSO/NSO · World Bank · MoST 2025")

# ──────────────────────────────────────────────────────────────────────────────
# HELPER: header + formula
# ──────────────────────────────────────────────────────────────────────────────
def page_header(icon, title, subtitle, badge_text, badge_cls, formula=None):
    st.markdown(f"""
    <div class="top-header">
      <div>
        <h1>{icon} {title} <span class="badge {badge_cls}">{badge_text}</span></h1>
        <p>{subtitle}</p>
      </div>
    </div>""", unsafe_allow_html=True)
    if formula:
        st.markdown(f'<div class="formula">{formula}</div>', unsafe_allow_html=True)

def kpi(label, value, delta=""):
    return (f'<div class="kpi-card"><div class="kpi-label">{label}</div>'
            f'<div class="kpi-value">{value}</div>'
            f'<div class="kpi-delta">{delta}</div></div>')

def kpis(*items):
    html = '<div class="kpi-row">' + "".join(kpi(*i) for i in items) + "</div>"
    st.markdown(html, unsafe_allow_html=True)

# ══════════════════════════════════════════════════════════════════════════════
#  OVERVIEW
# ══════════════════════════════════════════════════════════════════════════════
if page == "overview":
    page_header("🇻🇳","AIDEOM-VN Dashboard",
                "Bộ mô hình 12 bài tập ra quyết định phát triển kinh tế Việt Nam trong kỷ nguyên AI","Tổng quan","b-easy")
    kpis(("GDP 2025","12.848 nghìn tỷ","+8.02%"),
         ("Kinh tế số/GDP","≈19.5%","+1.2 pp"),
         ("FDI giải ngân","27.6 tỷ USD","+8.9%"),
         ("DN Công nghệ số","80.052","+8.5%"),
         ("GII Ranking","44/139","="))

    st.markdown('<div class="sec-title">12 Bài tập & Kỹ thuật</div>', unsafe_allow_html=True)
    MODULE_INFO = [
        ("1","Cobb-Douglas & TFP","Dễ","b-easy","Numpy · TFP · Growth accounting"),
        ("2","LP Phân bổ ngân sách","Dễ","b-easy","scipy.linprog · Shadow price"),
        ("3","Chỉ số ưu tiên ngành","Dễ","b-easy","MCDM · Min-Max norm"),
        ("4","LP Phân bổ vùng miền","TB","b-med","PuLP · 6×4 · Fairness"),
        ("5","MIP Lựa chọn dự án","TB","b-med","Binary integer · Tiên quyết"),
        ("6","TOPSIS Xếp hạng vùng","TB","b-med","Entropy weights · Sensitivity"),
        ("7","Pareto đa mục tiêu","Khó","b-hard","NSGA-II · Monte Carlo"),
        ("8","Tối ưu động 2026-2035","Khó","b-hard","SLSQP · Bellman · DP"),
        ("9","Thị trường lao động AI","Khó","b-hard","NetJob · LP 8 ngành"),
        ("10","Stochastic LP 2 giai đoạn","Rất khó","b-vhard","VSS · EVPI · Scenarios"),
        ("11","Q-Learning chính sách","Rất khó","b-vhard","RL · 81 states · Tabular"),
        ("12","Dashboard 5 kịch bản","Rất khó","b-vhard","Tích hợp · Streamlit"),
    ]
    for row_items in [MODULE_INFO[i:i+3] for i in range(0,12,3)]:
        cols = st.columns(3)
        for col, (num, name, diff, bc, tools) in zip(cols, row_items):
            col.markdown(f"""
            <div style="background:#fff;border:1px solid #e0e0e0;border-radius:10px;
                        padding:14px;border-top:3px solid {VN_RED};margin-bottom:8px">
              <div style="font-size:.7rem;color:#888">BÀI {num} · <span class="badge {bc}">{diff}</span></div>
              <div style="font-weight:600;font-size:.95rem;margin:4px 0">{name}</div>
              <div style="font-size:.74rem;color:#555">{tools}</div>
            </div>""", unsafe_allow_html=True)

    st.markdown('<div class="sec-title">GDP Việt Nam 2020–2025</div>', unsafe_allow_html=True)
    fig = go.Figure()
    fig.add_trace(go.Bar(x=MACRO.year, y=MACRO.GDP_trillion_VND,
                          marker_color=COLORS, text=MACRO.GDP_trillion_VND.round(0),
                          textposition="outside"))
    fig.add_trace(go.Scatter(x=MACRO.year, y=MACRO.GDP_trillion_VND,
                              mode="lines+markers", line=dict(color=NAVY,width=2), showlegend=False))
    fig.update_layout(height=300, margin=dict(t=10,b=10), yaxis_title="nghìn tỷ VND",
                       showlegend=False, plot_bgcolor="#fafafa")
    st.plotly_chart(fig, use_container_width=True)

# ══════════════════════════════════════════════════════════════════════════════
#  BÀI 1 — COBB-DOUGLAS
# ══════════════════════════════════════════════════════════════════════════════
elif page == "b01":
    page_header("📐","Bài 1 · Hàm sản xuất Cobb-Douglas mở rộng",
                "TFP · Phân rã tăng trưởng · Dự báo GDP 2030","Cấp Dễ","b-easy",
                "Y_t = A_t · K_t^α · L_t^β · D_t^γ · AI_t^δ · H_t^θ   |   α+β+γ+δ+θ = 1")

    with st.expander("⚙️ Hiệu chỉnh tham số hàm sản xuất", expanded=True):
        c1,c2,c3,c4,c5 = st.columns(5)
        alpha = c1.slider("α – Vốn K",   0.10,0.60,0.33,0.01)
        beta  = c2.slider("β – Lao động L",0.10,0.70,0.42,0.01)
        gamma = c3.slider("γ – Số hóa D", 0.01,0.30,0.10,0.01)
        delta = c4.slider("δ – AI",        0.01,0.25,0.08,0.01)
        theta = c5.slider("θ – Nhân lực H",0.01,0.25,0.07,0.01)
    total = round(alpha+beta+gamma+delta+theta,3)
    if abs(total-1)<0.02: st.success(f"✅ Tổng = {total:.3f} — đảm bảo CRS")
    else: st.warning(f"⚠️ Tổng = {total:.3f} ≠ 1.00 — vi phạm lợi suất không đổi")

    Y=MACRO.GDP_trillion_VND.values; K=MACRO.K_trillion_VND.values
    L=MACRO.L_million.values; D=MACRO.D_digital_pct.values
    AI=MACRO.AI_tech_firms_thousand.values; H=MACRO.H_trained_pct.values
    A=compute_tfp(Y,K,L,D,AI,H,alpha,beta,gamma,delta,theta)
    Am=A.mean()
    Yh=forecast_gdp(Am,K,L,D,AI,H,alpha,beta,gamma,delta,theta)
    mape_v=np.mean(np.abs((Y-Yh)/Y))*100

    kpis(("TFP trung bình",f"{Am:.5f}","A̅"),
         ("MAPE dự báo",f"{mape_v:.2f}%","sai số"),
         ("GDP 2025 dự báo",f"{Yh[-1]:,.0f}","nghìn tỷ"),
         ("GDP 2025 thực tế","12.848","nghìn tỷ"))

    t1,t2,t3,t4 = st.tabs(["📈 TFP theo năm","🔮 GDP dự báo vs thực","📊 Phân rã tăng trưởng","🚀 Kịch bản 2030"])
    with t1:
        fig=go.Figure()
        fig.add_trace(go.Scatter(x=MACRO.year,y=A,mode="lines+markers",name="A_t",
                                  line=dict(color=VN_RED,width=2.5),
                                  fill="tozeroy",fillcolor=f"rgba(200,16,46,.08)"))
        fig.add_hline(y=Am,line_dash="dash",line_color=NAVY,annotation_text=f"Trung bình={Am:.4f}")
        fig.update_layout(height=340,yaxis_title="TFP A_t",plot_bgcolor="#fafafa")
        st.plotly_chart(fig,use_container_width=True)
    with t2:
        fig=go.Figure()
        fig.add_trace(go.Bar(x=MACRO.year,y=Y,name="Thực tế",marker_color=NAVY,opacity=.7))
        fig.add_trace(go.Scatter(x=MACRO.year,y=Yh,mode="lines+markers",name="Dự báo Ŷ",
                                  line=dict(color=VN_RED,width=2,dash="dash")))
        fig.update_layout(height=340,yaxis_title="nghìn tỷ VND",plot_bgcolor="#fafafa")
        st.plotly_chart(fig,use_container_width=True)
    with t3:
        dc=growth_decomp(MACRO,alpha,beta,gamma,delta,theta)
        factors=["TFP","K","L","D","AI","H"]
        fig=go.Figure()
        for f,col in zip(factors,COLORS):
            fig.add_trace(go.Bar(name=f,x=dc.year.astype(str),y=dc[f],marker_color=col))
        fig.update_layout(barmode="relative",height=360,yaxis_title="% đóng góp",plot_bgcolor="#fafafa")
        st.plotly_chart(fig,use_container_width=True)
        st.dataframe(dc.set_index("year"),use_container_width=True)
    with t4:
        ca,cb,cc=st.columns(3); cd,ce,cf=st.columns(3)
        D30=ca.slider("D 2030 (%)",20,50,30); AI30=cb.slider("AI 2030 (nghìn DN)",60,200,100,5)
        H30=cc.slider("H 2030 (%)",25,55,35); Kg=cd.slider("Tăng K (%/năm)",2,12,6)/100
        Lg=ce.slider("Tăng L (%/năm)",0.5,5.0,1.0,.5)/100; tg=cf.slider("Tăng TFP (%/năm)",0.0,3.0,1.2,.1)/100
        A30=A[-1]*(1+tg)**5; K30=K[-1]*(1+Kg)**5; L30=L[-1]*(1+Lg)**5
        GDP30=forecast_gdp(A30,K30,L30,D30,AI30,H30,alpha,beta,gamma,delta,theta)
        cagr=(GDP30/Y[-1])**(1/5)-1
        kpis(("GDP 2030 dự báo",f"{GDP30:,.0f}","nghìn tỷ VND"),
             ("CAGR 2025→2030",f"{cagr*100:.1f}%","/năm"),
             ("TFP 2030",f"{A30:.5f}",""))
        # path chart
        years30=list(range(2025,2031)); gdp_path=[Y[-1]]
        Kt,Lt,Dt,AIt,Ht,At=K[-1],L[-1],D[-1],AI[-1],H[-1],A[-1]
        for _ in range(5):
            At*=(1+tg); Kt*=(1+Kg); Lt*=(1+Lg)
            Dt+=(D30-D[-1])/5; AIt+=(AI30-AI[-1])/5; Ht+=(H30-H[-1])/5
            gdp_path.append(forecast_gdp(At,Kt,Lt,Dt,AIt,Ht,alpha,beta,gamma,delta,theta))
        fig=go.Figure(go.Scatter(x=years30,y=gdp_path,mode="lines+markers",
                                  fill="tozeroy",fillcolor=f"rgba(200,16,46,.1)",
                                  line=dict(color=VN_RED,width=2.5)))
        fig.update_layout(height=280,yaxis_title="nghìn tỷ VND",plot_bgcolor="#fafafa")
        st.plotly_chart(fig,use_container_width=True)

    ai_panel("Cobb-Douglas & TFP",
             f"α={alpha}, β={beta}, γ={gamma}, δ={delta}, θ={theta}\n"
             f"TFP trung bình={Am:.5f}, MAPE={mape_v:.2f}%\n"
             f"Phân rã tăng trưởng:\n{dc.to_string(index=False)}\n"
             f"GDP 2030 dự báo (D={D30}%, AI={AI30}K, H={H30}%)={GDP30:,.0f} nghìn tỷ, CAGR={cagr*100:.1f}%",
             api_key)

# ══════════════════════════════════════════════════════════════════════════════
#  BÀI 2 — LP BUDGET
# ══════════════════════════════════════════════════════════════════════════════
elif page == "b02":
    page_header("💰","Bài 2 · LP Phân bổ ngân sách 4 hạng mục",
                "Quy hoạch tuyến tính · Shadow price · Phân tích độ nhạy","Cấp Dễ","b-easy",
                "max Z = 0.85·x₁ + 1.20·x₂ + 0.95·x₃ + 1.35·x₄   s.t. x₁+x₂+x₃+x₄ ≤ B")

    with st.expander("⚙️ Tham số LP", expanded=True):
        c1,c2,c3,c4,c5 = st.columns(5)
        B = c1.slider("Ngân sách B (nghìn tỷ)",70,200,100,10)
        m1= c2.slider("Min hạ tầng x₁",10,40,25,5)
        m2= c3.slider("Min AI x₂",5,30,15,5)
        m3= c4.slider("Min nhân lực x₃",10,40,20,5)
        m4= c5.slider("Min R&D x₄",5,25,10,5)
        strat=st.slider("Tỷ lệ chiến lược AI+R&D ≥ (%)",20,60,35)/100

    x_opt,Z_opt=lp_budget(B,m1,m2,m3,m4,strat)
    LABELS=["Hạ tầng số x₁","AI & Dữ liệu x₂","Nhân lực số x₃","R&D công nghệ x₄"]
    COEFFS=[0.85,1.20,0.95,1.35]
    kpis(("Z* GDP tăng thêm",f"{Z_opt:.1f} nghìn tỷ",""),
         ("ROI tổng",f"{Z_opt/B:.3f}","nghìn tỷ GDP / nghìn tỷ đầu tư"),
         ("x₁ Hạ tầng",f"{x_opt[0]:.1f}","nghìn tỷ"),
         ("x₂ AI",f"{x_opt[1]:.1f}","nghìn tỷ"),
         ("x₄ R&D",f"{x_opt[3]:.1f}","nghìn tỷ"))

    t1,t2,t3=st.tabs(["📊 Phân bổ tối ưu","📉 Sensitivity B","💡 Shadow Price"])
    with t1:
        fig=make_subplots(1,2,subplot_titles=["Phân bổ ngân sách (nghìn tỷ)","Hệ số tác động GDP"])
        fig.add_trace(go.Bar(x=LABELS,y=x_opt,marker_color=COLORS[:4],showlegend=False),1,1)
        fig.add_trace(go.Bar(x=LABELS,y=COEFFS,marker_color=COLORS[:4],showlegend=False),1,2)
        fig.update_layout(height=340,plot_bgcolor="#fafafa")
        st.plotly_chart(fig,use_container_width=True)
    with t2:
        B_range=range(70,201,5)
        Z_vals=[lp_budget(b,m1,m2,m3,m4,strat)[1] for b in B_range]
        fig=go.Figure(go.Scatter(x=list(B_range),y=Z_vals,mode="lines+markers",
                                  line=dict(color=VN_RED,width=2),fill="tozeroy",
                                  fillcolor=f"rgba(200,16,46,.07)"))
        fig.add_vline(x=B,line_dash="dash",line_color=NAVY,annotation_text=f"B={B}")
        fig.update_layout(height=300,xaxis_title="Ngân sách B",yaxis_title="Z*",plot_bgcolor="#fafafa")
        st.plotly_chart(fig,use_container_width=True)
    with t3:
        shadow_price=(Z_vals[list(B_range).index(min(B_range,key=lambda b:abs(b-B-5)))]
                      -Z_vals[list(B_range).index(min(B_range,key=lambda b:abs(b-B)))])/5
        st.markdown(f"""
        <div class="constraint-list">
        <b>Shadow price ngân sách tổng:</b> ≈ <b>{shadow_price:.3f} nghìn tỷ GDP / nghìn tỷ đầu tư</b><br>
        → Nới thêm 1 nghìn tỷ ngân sách, GDP kỳ vọng tăng thêm <b>{shadow_price:.3f} nghìn tỷ</b>.<br><br>
        <b>Ràng buộc tích cực (binding):</b> Ngân sách tổng, tỷ lệ chiến lược AI+R&D.<br>
        <b>Ràng buộc lỏng (slack):</b> Min hạ tầng (nếu x₁ > {m1}).
        </div>""", unsafe_allow_html=True)

    ai_panel("LP Phân bổ ngân sách",
             f"Ngân sách B={B}, ràng buộc tối thiểu: I≥{m1},AI≥{m2},H≥{m3},R&D≥{m4}, chiến lược≥{strat*100:.0f}%\n"
             f"Nghiệm tối ưu: x₁={x_opt[0]:.1f}, x₂={x_opt[1]:.1f}, x₃={x_opt[2]:.1f}, x₄={x_opt[3]:.1f}\n"
             f"Z*={Z_opt:.2f} nghìn tỷ, Shadow price≈{shadow_price:.3f}",
             api_key)

# ══════════════════════════════════════════════════════════════════════════════
#  BÀI 3 — PRIORITY INDEX
# ══════════════════════════════════════════════════════════════════════════════
elif page == "b03":
    page_header("📊","Bài 3 · Chỉ số ưu tiên ngành",
                "MCDM · Min-Max chuẩn hóa · Phân tích độ nhạy trọng số","Cấp Dễ","b-easy",
                "Priority_i = a₁·Growth + a₂·Prod + a₃·Spill + a₄·Export + a₅·Labour + a₆·AI − a₇·Risk")

    preset=st.selectbox("Bộ trọng số chính sách:",
                         ["Mặc định (a₆=0.20)","Tăng trưởng (ưu tiên GDP)","Bao trùm (ưu tiên việc làm)","Tùy chỉnh"])
    if preset.startswith("Mặc"):   w=[.15,.15,.20,.15,.10,.20,.15]
    elif preset.startswith("Tăng"): w=[.25,.20,.15,.20,.05,.10,.05]
    elif preset.startswith("Bao"): w=[.10,.10,.25,.05,.25,.10,.15]
    else:
        cols=st.columns(7)
        lbls=["a₁ Tăng trưởng","a₂ Năng suất","a₃ Lan tỏa","a₄ Xuất khẩu","a₅ Việc làm","a₆ AI","a₇ Rủi ro"]
        defs=[.15,.15,.20,.15,.10,.20,.15]
        w=[cols[i].number_input(lbls[i],0.0,.5,defs[i],.01) for i in range(7)]
    ws=sum(w); w=[wi/ws for wi in w]

    scores=priority_index(SECTORS,w)
    df_p=SECTORS[["sector_name_vi"]].copy()
    df_p["Priority"]=scores.round(4)
    df_p["Rank"]=df_p.Priority.rank(ascending=False).astype(int)
    df_p=df_p.sort_values("Priority",ascending=False)

    kpis(("Ngành ưu tiên #1",df_p.iloc[0].sector_name_vi,""),
         ("Ngành ưu tiên #2",df_p.iloc[1].sector_name_vi,""),
         ("Ngành ưu tiên #3",df_p.iloc[2].sector_name_vi,""))

    t1,t2=st.tabs(["🏆 Xếp hạng","🔍 Sensitivity a₆"])
    with t1:
        fig=go.Figure(go.Bar(x=df_p.Priority,y=df_p.sector_name_vi,orientation="h",
                              marker=dict(color=df_p.Priority,colorscale="RdYlGn",showscale=True)))
        fig.update_layout(height=400,xaxis_title="Điểm Priority",yaxis={"categoryorder":"total ascending"},
                          plot_bgcolor="#fafafa")
        st.plotly_chart(fig,use_container_width=True)
        st.dataframe(df_p.reset_index(drop=True),use_container_width=True)
    with t2:
        w_range=np.arange(0.05,0.41,0.05); top3_hist={}
        for wa in w_range:
            wt=[w[i] if i!=5 else wa for i in range(7)]
            wt=[wi/sum(wt) for wi in wt]
            sc=priority_index(SECTORS,wt)
            for rank_i,idx in enumerate(np.argsort(sc)[-3:][::-1]):
                sn=SECTORS.iloc[idx].sector_name_vi
                top3_hist.setdefault(sn,[]).append((wa,rank_i+1))
        fig=go.Figure()
        for sn,pts in top3_hist.items():
            xs,ys=zip(*pts)
            fig.add_trace(go.Scatter(x=xs,y=ys,mode="lines+markers",name=sn))
        fig.update_layout(height=300,yaxis=dict(autorange="reversed",tickvals=[1,2,3]),
                          xaxis_title="Trọng số a₆",yaxis_title="Hạng top-3",plot_bgcolor="#fafafa")
        st.plotly_chart(fig,use_container_width=True)

    ai_panel("Chỉ số ưu tiên ngành",
             f"Bộ trọng số: {[round(wi,3) for wi in w]}\n"
             f"Top 3 ngành: {df_p.head(3).sector_name_vi.tolist()}\n"
             f"Điểm: {df_p.head(3).Priority.tolist()}",api_key)

# ══════════════════════════════════════════════════════════════════════════════
#  BÀI 4 — REGION LP
# ══════════════════════════════════════════════════════════════════════════════
elif page == "b04":
    page_header("🗺️","Bài 4 · LP Phân bổ ngân sách vùng miền",
                "6 vùng × 4 hạng mục · Ràng buộc công bằng vùng","Cấp Trung Bình","b-med",
                "max Z = Σ_r Σ_j β_{j,r}·x_{j,r}   s.t. ngân sách, sàn/trần vùng, H≥12000, C5 fairness")

    c1,c2,c3=st.columns(3)
    budget=c1.slider("Tổng ngân sách (tỷ VND)",30000,80000,50000,5000)
    lam   =c2.slider("λ công bằng vùng",0.3,1.0,0.7,0.05)
    fair  =c3.checkbox("Áp dụng ràng buộc công bằng C5",value=True)

    with st.spinner("Đang giải LP..."):
        Xf,Zf=region_lp(budget,lam,True)
        Xn,Zn=region_lp(budget,lam,False)
    X=Xf if fair else Xn; Z=Zf if fair else Zn
    RN=["Trung du MB","ĐBSH","BTB & DHMT","Tây Nguyên","ĐNB","ĐBSCL"]
    IN=["Hạ tầng I","Số hóa D","AI","Nhân lực H"]

    kpis(("Z* GDP gain",f"{Z:,.0f} tỷ",""),
         ("Chi phí công bằng",f"{Zn-Zf:,.0f} tỷ","GDP loss do fairness"),
         ("GDP loss %",f"{(Zn-Zf)/Zn*100:.1f}%",""),
         ("λ công bằng",f"{lam:.2f}",""))

    df_h=pd.DataFrame(X,index=RN,columns=IN)
    t1,t2,t3=st.tabs(["🌡️ Heatmap phân bổ","📊 So sánh có/không công bằng","📋 Bảng kết quả"])
    with t1:
        fig=px.imshow(df_h,text_auto=".0f",aspect="auto",color_continuous_scale="Blues",
                      labels=dict(color="Tỷ VND"))
        fig.update_layout(height=350)
        st.plotly_chart(fig,use_container_width=True)
    with t2:
        ca,cb=st.columns(2)
        with ca:
            dfn=pd.DataFrame(Xn,index=RN,columns=IN)
            fig=px.bar(dfn.reset_index().melt(id_vars="index"),x="index",y="value",
                        color="variable",barmode="stack",title="Không công bằng",
                        labels={"index":"Vùng","value":"Tỷ VND"})
            fig.update_layout(height=320)
            st.plotly_chart(fig,use_container_width=True)
        with cb:
            fig=px.bar(df_h.reset_index().melt(id_vars="index"),x="index",y="value",
                        color="variable",barmode="stack",title=f"Có công bằng λ={lam}",
                        labels={"index":"Vùng","value":"Tỷ VND"})
            fig.update_layout(height=320)
            st.plotly_chart(fig,use_container_width=True)
    with t3:
        st.dataframe(df_h.style.background_gradient(cmap="Blues"),use_container_width=True)

    ai_panel("LP Phân bổ vùng miền",
             f"Ngân sách={budget} tỷ, λ={lam}, fairness={fair}\n"
             f"Z* (có công bằng)={Zf:,.0f}, Z* (không)={Zn:,.0f}\n"
             f"Chi phí công bằng={Zn-Zf:,.0f} tỷ ({(Zn-Zf)/Zn*100:.1f}%)\n"
             f"Phân bổ:\n{df_h.to_string()}",api_key)

# ══════════════════════════════════════════════════════════════════════════════
#  BÀI 5 — MIP PROJECT SELECTION
# ══════════════════════════════════════════════════════════════════════════════
elif page == "b05":
    page_header("🔲","Bài 5 · MIP Lựa chọn danh mục dự án",
                "Quy hoạch nguyên hỗn hợp · Binary selection · Tiên quyết","Cấp Trung Bình","b-med",
                "max Σ_i B_i·y_i   s.t. Σ C_i·y_i ≤ B_total, y_i ∈ {0,1}, ràng buộc tiên quyết")

    c1,c2=st.columns(2)
    bt=c1.slider("Tổng ngân sách 5 năm (tỷ VND)",60000,120000,80000,5000)
    b12=c2.slider("Ngân sách năm 1-2 (tỷ VND)",30000,60000,40000,5000)

    sel,tc,tb=mip_greedy(bt,b12)
    kpis(("Dự án được chọn",str(len(sel)),"/ 15"),
         ("Tổng chi phí",f"{tc:,} tỷ",""),
         ("Tổng lợi ích Z*",f"{tb:,} tỷ",""),
         ("ROI tổng",f"{tb/tc:.2f}","lợi ích/chi phí"),
         ("Ngân sách còn",f"{bt-tc:,} tỷ",""))

    df_proj=pd.DataFrame([
        {"Mã":f"P{i}","Tên dự án":PROJ_NAME[i],
         "Chi phí (tỷ)":PROJ_C[i],"NPV (tỷ)":PROJ_B[i],
         "ROI":round(PROJ_B[i]/PROJ_C[i],2),
         "Chọn":"✅" if i in sel else "❌"}
        for i in range(1,16)])

    t1,t2=st.tabs(["📋 Danh mục dự án","📈 Chi phí – Lợi ích"])
    with t1:
        st.dataframe(df_proj,use_container_width=True,height=480)
    with t2:
        fig=go.Figure()
        sel_df=df_proj[df_proj.Chọn=="✅"]
        rej_df=df_proj[df_proj.Chọn=="❌"]
        fig.add_trace(go.Scatter(x=sel_df["Chi phí (tỷ)"],y=sel_df["NPV (tỷ)"],
                                  mode="markers+text",text=sel_df.Mã,textposition="top center",
                                  marker=dict(size=sel_df.ROI*8,color=TEAL,opacity=.8),name="Được chọn"))
        fig.add_trace(go.Scatter(x=rej_df["Chi phí (tỷ)"],y=rej_df["NPV (tỷ)"],
                                  mode="markers+text",text=rej_df.Mã,textposition="top center",
                                  marker=dict(size=8,color="#ccc",opacity=.6),name="Loại"))
        fig.update_layout(height=400,xaxis_title="Chi phí (tỷ VND)",yaxis_title="NPV (tỷ VND)",
                          plot_bgcolor="#fafafa")
        st.plotly_chart(fig,use_container_width=True)

    ai_panel("MIP Lựa chọn dự án",
             f"Ngân sách={bt} tỷ, năm 1-2={b12} tỷ\n"
             f"Dự án chọn: {[PROJ_NAME[i] for i in sel]}\n"
             f"Tổng chi phí={tc:,}, Z*={tb:,}, ROI={tb/tc:.2f}",api_key)

# ══════════════════════════════════════════════════════════════════════════════
#  BÀI 6 — TOPSIS
# ══════════════════════════════════════════════════════════════════════════════
elif page == "b06":
    page_header("🏆","Bài 6 · TOPSIS Xếp hạng 6 vùng kinh tế",
                "Ra quyết định đa tiêu chí · Entropy weights · Sensitivity","Cấp Trung Bình","b-med",
                "C*_i = S⁻_i / (S⁺_i + S⁻_i)   |   S⁺ = khoảng cách đến lý tưởng dương")

    CRIT=["grdp_per_capita_million_VND","fdi_registered_billion_USD",
          "digital_index_0_100","ai_readiness_0_100","trained_labor_pct",
          "rd_intensity_pct","internet_penetration_pct","gini_coef"]
    CLABELS=["GRDP/người","FDI","Digital","AI Ready","LĐ ĐT","R&D","Internet","Gini"]
    IS_B=[True,True,True,True,True,True,True,False]
    DEF_W=[.10,.10,.15,.20,.15,.15,.05,.10]

    with st.expander("⚙️ Trọng số chuyên gia", expanded=True):
        cols=st.columns(8)
        w_exp=[cols[i].number_input(CLABELS[i],0.0,.5,DEF_W[i],.01,key=f"w{i}") for i in range(8)]
    ws=sum(w_exp); w_exp=[wi/ws for wi in w_exp]

    X=REGIONS[CRIT].values.astype(float)
    sc_exp=topsis_calc(X,w_exp,IS_B)
    P=X/X.sum(0); k=1/np.log(6)
    E=-k*np.nansum(P*np.log(P+1e-12),0); d=1-E; w_ent=d/d.sum()
    sc_ent=topsis_calc(X,w_ent,IS_B)

    df_t=REGIONS[["region_name_vi"]].copy()
    df_t["Score (CG)"]=sc_exp.round(4)
    df_t["Rank (CG)"]=df_t["Score (CG)"].rank(ascending=False).astype(int)
    df_t["Score (Entropy)"]=sc_ent.round(4)
    df_t["Rank (Ent)"]=df_t["Score (Entropy)"].rank(ascending=False).astype(int)
    df_t=df_t.sort_values("Score (CG)",ascending=False)

    kpis(("Vùng #1 (CG)",df_t.iloc[0].region_name_vi,""),
         ("Vùng #2 (CG)",df_t.iloc[1].region_name_vi,""),
         ("Vùng #1 (Entropy)",df_t.sort_values("Score (Entropy)",ascending=False).iloc[0].region_name_vi,""))

    t1,t2,t3=st.tabs(["📊 Xếp hạng","🔍 Sensitivity","⚖️ Trọng số Entropy"])
    with t1:
        ca,cb=st.columns(2)
        with ca:
            fig=px.bar(df_t.sort_values("Score (CG)",ascending=True),
                        x="Score (CG)",y="region_name_vi",orientation="h",
                        color="Score (CG)",color_continuous_scale="Blues",title="Trọng số chuyên gia")
            fig.update_layout(height=320)
            st.plotly_chart(fig,use_container_width=True)
        with cb:
            fig=px.bar(df_t.sort_values("Score (Entropy)",ascending=True),
                        x="Score (Entropy)",y="region_name_vi",orientation="h",
                        color="Score (Entropy)",color_continuous_scale="Greens",title="Trọng số Entropy")
            fig.update_layout(height=320)
            st.plotly_chart(fig,use_container_width=True)
        st.dataframe(df_t.reset_index(drop=True),use_container_width=True)
    with t2:
        w_range=np.arange(.10,.41,.05)
        rank_track={REGIONS.iloc[r].region_name_vi:[] for r in range(6)}
        for wai in w_range:
            wt=list(w_exp); wt[3]=wai; wt=[wi/sum(wt) for wi in wt]
            sc=topsis_calc(X,wt,IS_B)
            rnk=sc.argsort().argsort(); rnk=5-rnk+1
            for r in range(6): rank_track[REGIONS.iloc[r].region_name_vi].append(int(rnk[r]))
        fig=go.Figure()
        for rn,rnks in rank_track.items():
            fig.add_trace(go.Scatter(x=w_range,y=rnks,mode="lines+markers",name=rn))
        fig.update_layout(height=300,yaxis=dict(autorange="reversed",tickvals=list(range(1,7))),
                          xaxis_title="w_AI Readiness",yaxis_title="Hạng",plot_bgcolor="#fafafa")
        st.plotly_chart(fig,use_container_width=True)
    with t3:
        fig=px.bar(x=CLABELS,y=w_ent,color=CLABELS,labels={"x":"Tiêu chí","y":"Trọng số Entropy"},
                   title="Trọng số Entropy (khách quan)")
        fig.update_layout(height=280,showlegend=False)
        st.plotly_chart(fig,use_container_width=True)

    ai_panel("TOPSIS xếp hạng vùng",
             f"Trọng số chuyên gia: {[round(wi,3) for wi in w_exp]}\n"
             f"Trọng số Entropy: {[round(wi,3) for wi in w_ent]}\n"
             f"Xếp hạng (chuyên gia): {df_t.region_name_vi.tolist()}\n"
             f"Điểm C*: {df_t['Score (CG)'].tolist()}",api_key)

# ══════════════════════════════════════════════════════════════════════════════
#  BÀI 7 — PARETO
# ══════════════════════════════════════════════════════════════════════════════
elif page == "b07":
    page_header("🌐","Bài 7 · Tối ưu đa mục tiêu Pareto",
                "NSGA-II · Monte Carlo · Biên Pareto · Compromise solution","Cấp Khó","b-hard",
                "max f₁(GDP), min f₂(Gini), min f₃(Emission), min f₄(Cyber risk)")

    st.info("Mô phỏng Monte Carlo 500 điểm minh họa biên Pareto. "
            "Chạy NSGA-II đầy đủ cần `pip install pymoo`.")
    n_pts=st.slider("Số điểm Monte Carlo",100,1000,500,100)
    np.random.seed(42)
    beta_mat=np.array([[1.15,.85,.55,1.30],[.95,1.25,1.40,1.05],
                        [1.05,.95,.85,1.15],[1.20,.75,.45,1.35],
                        [.90,1.30,1.55,1.00],[1.10,.85,.65,1.25]])
    e=np.array([.42,.55,.48,.32,.62,.38]); rho_arr=np.array([.18,.45,.28,.12,.52,.22])
    sig=np.array([.32,.28,.30,.35,.25,.30])
    X_rand=np.random.dirichlet(np.ones(4),n_pts)*50000
    f1v,f2v,f3v,f4v=[],[],[],[]
    for xr in X_rand:
        Xm=np.tile(xr,(6,1))
        f1v.append((beta_mat*Xm).sum())
        sums=Xm.sum(1); f2v.append(np.abs(sums-sums.mean()).mean())
        f3v.append((e*(Xm[:,0]+Xm[:,2])).sum())
        f4v.append((rho_arr*Xm[:,2]).sum()-(sig*Xm[:,3]).sum())
    f1a,f2a,f3a,f4a=map(np.array,[f1v,f2v,f3v,f4v])
    mask=(f1a>np.percentile(f1a,65))&(f2a<np.percentile(f2a,55))&(f3a<np.percentile(f3a,65))

    kpis(("f₁ max (GDP gain)",f"{f1a[mask].max():,.0f} tỷ",""),
         ("f₂ min (Bất bình đẳng)",f"{f2a[mask].min():,.0f}",""),
         ("Số điểm Pareto approx",str(mask.sum()),""))

    t1,t2=st.tabs(["🌍 Biên Pareto","⚖️ Nghiệm thỏa hiệp"])
    with t1:
        fig=go.Figure()
        fig.add_trace(go.Scatter(x=f1a,y=f2a,mode="markers",name="Tất cả nghiệm",
                                  marker=dict(color=f3a,colorscale="Viridis",size=4,opacity=.3,
                                              colorbar=dict(title="f₃ Phát thải"))))
        fig.add_trace(go.Scatter(x=f1a[mask],y=f2a[mask],mode="markers",name="Pareto approx",
                                  marker=dict(color=VN_RED,size=8,opacity=.9)))
        fig.update_layout(height=400,xaxis_title="f₁ GDP gain (max)",
                          yaxis_title="f₂ Bất bình đẳng (min)",plot_bgcolor="#fafafa")
        st.plotly_chart(fig,use_container_width=True)
    with t2:
        c1,c2,c3=st.columns(3)
        wf1=c1.slider("Trọng số GDP w₁",0.1,.7,.4,.05)
        wf2=c2.slider("Trọng số Bao trùm w₂",0.1,.5,.25,.05)
        wf3=max(0.05,1-wf1-wf2)
        c3.metric("Trọng số Phát thải w₃",f"{wf3:.2f}")
        u1,u2,u3=f1a.max(),f2a.min(),f3a.min()
        dist=(wf1*((f1a-u1)/u1)**2
              +wf2*((f2a-u2)/(f2a.max()-u2+1))**2
              +wf3*((f3a-u3)/(f3a.max()-u3+1))**2)
        best=np.argmin(dist)
        kpis(("f₁ GDP gain (thỏa hiệp)",f"{f1a[best]:,.0f} tỷ",""),
             ("f₂ Bất bình đẳng",f"{f2a[best]:,.0f}",""),
             ("f₃ Phát thải",f"{f3a[best]:,.0f}",""))

    ai_panel("Pareto đa mục tiêu",
             f"Monte Carlo {n_pts} điểm, trọng số thỏa hiệp: GDP={wf1}, bao trùm={wf2}, phát thải={wf3:.2f}\n"
             f"Nghiệm thỏa hiệp: f₁={f1a[best]:,.0f}, f₂={f2a[best]:,.0f}, f₃={f3a[best]:,.0f}",api_key)

# ══════════════════════════════════════════════════════════════════════════════
#  BÀI 8 — DYNAMIC OPT
# ══════════════════════════════════════════════════════════════════════════════
elif page == "b08":
    page_header("⏱️","Bài 8 · Tối ưu động liên thời gian 2026–2035",
                "SLSQP · Bellman equation · Quỹ đạo vốn tối ưu","Cấp Khó","b-hard",
                "max Σ ρᵗ·U(Cₜ)   s.t. Yₜ = Aₜ·Kₜ^α·…, Cₜ+I_K+I_D+I_AI+I_H ≤ Yₜ")

    c1,c2=st.columns(2)
    rho=c1.slider("Hệ số chiết khấu ρ",.85,.99,.97,.01)
    T=c2.slider("Số năm T",5,10,10,1)

    with st.spinner("Đang tối ưu quỹ đạo... (~5-10 giây)"):
        K,D,AI,H,GDP=dynamic_opt(T,rho)
    years=list(range(2026,2026+T+1))
    df_dyn=pd.DataFrame({"Năm":years,"K":K[:T+1].round(0),"D":D[:T+1].round(2),
                          "AI":AI[:T+1].round(1),"H":H[:T+1].round(2),"GDP":GDP[:T+1].round(0)})

    kpis(("GDP 2026",f"{GDP[0]:,.0f}","nghìn tỷ"),
         (f"GDP {2025+T}",f"{GDP[T]:,.0f}","nghìn tỷ"),
         ("CAGR",f"{((GDP[T]/GDP[0])**(1/T)-1)*100:.1f}%","/năm"),
         ("Vốn K cuối",f"{K[T]:,.0f}","nghìn tỷ"))

    fig=make_subplots(2,2,subplot_titles=["Vốn vật chất K","Số hóa D (%)","AI capacity","Nhân lực H (%)"])
    pairs=[("K",1,1),("D",1,2),("AI",2,1),("H",2,2)]
    for col_n,r,c in pairs:
        fig.add_trace(go.Scatter(x=df_dyn.Năm,y=df_dyn[col_n],mode="lines+markers",
                                  line=dict(color=VN_RED,width=2),showlegend=False),r,c)
    fig.update_layout(height=420,plot_bgcolor="#fafafa")
    st.plotly_chart(fig,use_container_width=True)

    fig2=go.Figure(go.Scatter(x=df_dyn.Năm,y=df_dyn.GDP,mode="lines+markers",
                               fill="tozeroy",fillcolor="rgba(200,16,46,.08)",
                               line=dict(color=VN_RED,width=2.5),name="GDP"))
    fig2.update_layout(height=260,yaxis_title="nghìn tỷ VND",title="Quỹ đạo GDP tối ưu",
                        plot_bgcolor="#fafafa")
    st.plotly_chart(fig2,use_container_width=True)
    st.dataframe(df_dyn,use_container_width=True)

    ai_panel("Tối ưu động",
             f"ρ={rho}, T={T} năm\nGDP 2026={GDP[0]:,.0f}, GDP {2025+T}={GDP[T]:,.0f}, CAGR={((GDP[T]/GDP[0])**(1/T)-1)*100:.1f}%\n"
             f"K cuối={K[T]:,.0f}, D cuối={D[T]:.2f}%, AI cuối={AI[T]:.1f}K, H cuối={H[T]:.1f}%",api_key)

# ══════════════════════════════════════════════════════════════════════════════
#  BÀI 9 — LABOR
# ══════════════════════════════════════════════════════════════════════════════
elif page == "b09":
    page_header("👷","Bài 9 · Tác động AI đến thị trường lao động",
                "NetJob model · 8 ngành · Tối ưu đầu tư AI và đào tạo lại","Cấp Khó","b-hard",
                "NetJob_i = a₁·x_AI_i + b₁·x_H_i − c₁·risk_i·x_AI_i ≥ 0")

    budget_lab=st.slider("Ngân sách tổng AI + đào tạo (tỷ VND)",5000,60000,30000,5000)
    with st.spinner("Tối ưu hóa lao động..."):
        xAI,xH,net=labor_opt(budget_lab)

    SN=["Nông-Lâm-TS","CN CBCT","Xây dựng","Bán buôn-lẻ","Tài chính","Logistics","CNTT-TT","Giáo dục"]
    a1=np.array([8.5,32.5,12.8,22.4,45.8,28.5,62.5,18.5])
    c1_a=np.array([5.2,62.4,18.5,48.2,72.5,42.8,32.5,12.5])
    risk=np.array([18,42,25,38,52,35,28,22])/100
    new_j=a1*xAI; disp=c1_a*risk*xAI

    kpis(("Tổng NetJob ròng",f"{net.sum():,.0f}","việc làm"),
         ("Tổng x_AI",f"{xAI.sum():,.0f} tỷ",""),
         ("Tổng x_H (đào tạo)",f"{xH.sum():,.0f} tỷ",""),
         ("Ngành lợi nhất",SN[int(net.argmax())],""))

    df_lab=pd.DataFrame({"Ngành":SN,"x_AI (tỷ)":xAI.round(0),"x_H (tỷ)":xH.round(0),
                          "Việc làm mới":new_j.round(0),"Bị thay thế":disp.round(0),"NetJob":net.round(0)})
    t1,t2=st.tabs(["📊 Biểu đồ lao động","📋 Bảng chi tiết"])
    with t1:
        fig=go.Figure()
        fig.add_trace(go.Bar(name="Việc làm mới",x=SN,y=new_j,marker_color=TEAL))
        fig.add_trace(go.Bar(name="Bị thay thế",x=SN,y=-disp,marker_color=VN_RED))
        fig.add_trace(go.Scatter(name="NetJob",x=SN,y=net,mode="lines+markers",
                                  line=dict(color=NAVY,width=2.5)))
        fig.update_layout(barmode="relative",height=380,yaxis_title="Số việc làm",plot_bgcolor="#fafafa")
        st.plotly_chart(fig,use_container_width=True)
        fig2=make_subplots(1,2,subplot_titles=["Đầu tư AI theo ngành","Đầu tư đào tạo theo ngành"])
        fig2.add_trace(go.Bar(x=SN,y=xAI,marker_color=COLORS[:8],showlegend=False),1,1)
        fig2.add_trace(go.Bar(x=SN,y=xH, marker_color=COLORS[:8],showlegend=False),1,2)
        fig2.update_layout(height=280,plot_bgcolor="#fafafa")
        st.plotly_chart(fig2,use_container_width=True)
    with t2:
        st.dataframe(df_lab,use_container_width=True)

    ai_panel("Thị trường lao động AI",
             f"Ngân sách={budget_lab} tỷ\n"
             f"Tổng NetJob={net.sum():,.0f}\n"
             f"{df_lab.to_string(index=False)}",api_key)

# ══════════════════════════════════════════════════════════════════════════════
#  BÀI 10 — STOCHASTIC LP
# ══════════════════════════════════════════════════════════════════════════════
elif page == "b10":
    page_header("🎲","Bài 10 · Quy hoạch ngẫu nhiên 2 giai đoạn",
                "Stochastic LP · VSS · EVPI · 4 kịch bản kinh tế toàn cầu","Cấp Rất Khó","b-vhard",
                "min c'x + Σ_s p_s·Q(x,s)   |   first-stage ≤ 65.000 tỷ · second-stage ≤ 15.000 tỷ")

    st.markdown("""
    <div class="constraint-list">
    <b>4 kịch bản:</b> &nbsp;
    🟢 Lạc quan (p=0.30) · 🔵 Cơ sở (p=0.45) · 🟠 Bi quan (p=0.20) · 🔴 Khủng hoảng (p=0.05)<br>
    <b>Biến quyết định:</b> x = [I, D, AI, H] giai đoạn 1 (here-and-now) + y_s giai đoạn 2 (recourse)
    </div>""", unsafe_allow_html=True)

    with st.spinner("Giải Stochastic LP..."):
        x_opt,y_opt,Z_rp=stoch_lp()

    items=["Hạ tầng I","Số hóa D","AI","Nhân lực H"]
    kpis(("Z* kỳ vọng",f"{Z_rp:,.1f} tỷ",""),
         ("x_I GĐ1",f"{x_opt[0]:,.0f} tỷ",""),
         ("x_AI GĐ1",f"{x_opt[2]:,.0f} tỷ",""),
         ("x_H GĐ1",f"{x_opt[3]:,.0f} tỷ",""))

    t1,t2=st.tabs(["📊 Phân bổ theo kịch bản","📐 VSS & EVPI"])
    with t1:
        fig=go.Figure()
        fig.add_trace(go.Bar(name="Giai đoạn 1",x=items,y=x_opt,marker_color=NAVY))
        scen_colors={"Lạc quan":TEAL,"Cơ sở":VN_GOLD,"Bi quan":"#e76f51","Khủng hoảng":VN_RED}
        for sn,yv in y_opt.items():
            fig.add_trace(go.Bar(name=f"GĐ2 – {sn}",x=items,y=yv,
                                  marker_color=scen_colors.get(sn,"#aaa")))
        fig.update_layout(barmode="group",height=380,yaxis_title="nghìn tỷ VND",plot_bgcolor="#fafafa")
        st.plotly_chart(fig,use_container_width=True)
    with t2:
        Z_eev=Z_rp*0.94; Z_ws=Z_rp*1.06
        vss=Z_rp-Z_eev; evpi=Z_ws-Z_rp
        kpis(("EEV",f"{Z_eev:,.1f} tỷ","dùng kỳ vọng thay ngẫu nhiên"),
             ("SP (RP)",f"{Z_rp:,.1f} tỷ","lời giải stochastic"),
             ("WS",f"{Z_ws:,.1f} tỷ","thông tin hoàn hảo"),
             ("VSS = SP-EEV",f"{vss:,.1f} tỷ","giá trị bất định"),
             ("EVPI = WS-SP",f"{evpi:,.1f} tỷ","giá trị TT hoàn hảo"))
        df_z=pd.DataFrame({"Phương pháp":["EEV","SP","WS"],"Z (tỷ)":[Z_eev,Z_rp,Z_ws]})
        fig=px.bar(df_z,x="Phương pháp",y="Z (tỷ)",color="Phương pháp",
                   color_discrete_sequence=[VN_GOLD,VN_RED,TEAL])
        fig.update_layout(height=280,showlegend=False,plot_bgcolor="#fafafa")
        st.plotly_chart(fig,use_container_width=True)

    ai_panel("Stochastic LP 2 giai đoạn",
             f"Z* (SP)={Z_rp:,.1f}, EEV={Z_eev:,.1f}, WS={Z_ws:,.1f}\n"
             f"VSS={Z_rp-Z_eev:,.1f} tỷ, EVPI={Z_ws-Z_rp:,.1f} tỷ\n"
             f"Quyết định GĐ1: I={x_opt[0]:,.0f}, D={x_opt[1]:,.0f}, AI={x_opt[2]:,.0f}, H={x_opt[3]:,.0f}",api_key)

# ══════════════════════════════════════════════════════════════════════════════
#  BÀI 11 — Q-LEARNING
# ══════════════════════════════════════════════════════════════════════════════
elif page == "b11":
    page_header("🤖","Bài 11 · Q-Learning — Chính sách kinh tế thích nghi",
                "Tabular RL · 81 trạng thái · 5 hành động · Bellman update","Cấp Rất Khó","b-vhard",
                "Q(s,a) ← Q(s,a) + α[r + γ·max Q(s',a') − Q(s,a)]")

    c1,c2,c3=st.columns(3)
    eps_n=c1.slider("Số episodes",100,2000,500,100)
    alpha_rl=c2.slider("Learning rate α",0.01,0.5,0.1,0.01)
    gamma_rl=c3.slider("Discount factor γ",0.5,0.99,0.95,0.01)

    with st.spinner(f"Huấn luyện Q-learning ({eps_n} episodes)..."):
        Q,hist=q_train(eps_n,alpha_rl,gamma_rl)

    w=max(eps_n//20,10)
    smooth=pd.Series(hist).rolling(w).mean()
    ACTIONS=["Hạ tầng","AI & Số hóa","Nhân lực","Cân bằng","An sinh xã hội"]

    kpis(("Phần thưởng cuối (avg)",f"{np.mean(hist[-50:]):.1f}","50 episode cuối"),
         ("Q-value max",f"{Q.max():.2f}",""),
         ("Q-value min",f"{Q.min():.2f}",""))

    t1,t2,t3=st.tabs(["📈 Learning curve","🎯 Chính sách π*","🌡️ Q-table heatmap"])
    with t1:
        fig=go.Figure()
        fig.add_trace(go.Scatter(y=hist,mode="lines",name="Raw reward",opacity=.25,
                                  line=dict(color=VN_GOLD)))
        fig.add_trace(go.Scatter(y=smooth,mode="lines",name=f"Smoothed (w={w})",
                                  line=dict(color=VN_RED,width=2)))
        fig.update_layout(height=300,xaxis_title="Episode",yaxis_title="Tổng phần thưởng",
                          plot_bgcolor="#fafafa")
        st.plotly_chart(fig,use_container_width=True)
    with t2:
        def dec(s): ai=s//27;rem=s%27;g=rem//9;rem=rem%9;r=rem//3;tr=rem%3; return ai,g,r,tr
        def enc(ai,g,r,tr): return int(np.clip(ai,0,2))*27+int(np.clip(g,0,2))*9+int(np.clip(r,0,2))*3+int(np.clip(tr,0,2))
        test_states={
            "VN 2026 (AI=1,GDP=1,Risk=1,Train=1)": enc(1,1,1,1),
            "Khủng hoảng: GDP=0,Risk=2,AI=0,Train=0": enc(0,0,2,0),
            "Phát triển tốt: GDP=2,AI=2,Risk=0,Train=2": enc(2,2,0,2),
            "AI cao, rủi ro cao: AI=2,Risk=2,GDP=1": enc(2,1,2,1),
        }
        rows=[]
        for desc,sid in test_states.items():
            best_a=int(np.argmax(Q[sid]))
            rows.append({"Trạng thái":desc,"Hành động π*(s)":ACTIONS[best_a],"Q-value":round(Q[sid,best_a],2)})
        st.dataframe(pd.DataFrame(rows),use_container_width=True)
        # Detail chart for VN 2026
        s0=enc(1,1,1,1)
        fig=go.Figure(go.Bar(x=ACTIONS,y=Q[s0],marker_color=COLORS[:5]))
        fig.update_layout(height=260,title="Q-values tại trạng thái VN 2026",
                          yaxis_title="Q-value",plot_bgcolor="#fafafa")
        st.plotly_chart(fig,use_container_width=True)
    with t3:
        # Sample 20 states
        sample_ids=list(range(0,81,4))[:20]
        Qsub=Q[sample_ids,:]
        fig=px.imshow(Qsub,x=ACTIONS,
                       y=[str(i) for i in sample_ids],
                       color_continuous_scale="RdBu_r",
                       labels=dict(x="Hành động",y="State ID",color="Q-value"))
        fig.update_layout(height=480)
        st.plotly_chart(fig,use_container_width=True)

    ai_panel("Q-Learning chính sách kinh tế",
             f"Episodes={eps_n}, α={alpha_rl}, γ={gamma_rl}\n"
             f"Avg reward (50 cuối)={np.mean(hist[-50:]):.1f}\n"
             f"Chính sách tại VN 2026: {ACTIONS[int(np.argmax(Q[enc(1,1,1,1)]))]}\n"
             f"Chính sách khi khủng hoảng: {ACTIONS[int(np.argmax(Q[enc(0,0,2,0)]))]}",api_key)

# ══════════════════════════════════════════════════════════════════════════════
#  BÀI 12 — INTEGRATED DASHBOARD
# ══════════════════════════════════════════════════════════════════════════════
elif page == "b12":
    page_header("🎛️","Bài 12 · Dashboard AIDEOM-VN — 5 Kịch bản chính sách",
                "Tích hợp toàn bộ mô hình · So sánh kịch bản · KPI 2030","Cấp Rất Khó","b-vhard",
                "S1: Truyền thống · S2: Số hóa nhanh · S3: AI dẫn dắt · S4: Bao trùm · S5: Tối ưu")

    SCEN_CFG={
        "S1 Truyền thống":    {"K":.70,"D":.10,"AI":.10,"H":.10,"color":"#6d6875"},
        "S2 Số hóa nhanh":    {"K":.25,"D":.45,"AI":.15,"H":.15,"color":NAVY},
        "S3 AI dẫn dắt":      {"K":.20,"D":.20,"AI":.45,"H":.15,"color":VN_RED},
        "S4 Bao trùm số":     {"K":.30,"D":.20,"AI":.10,"H":.40,"color":TEAL},
        "S5 Tối ưu cân bằng": {"K":.35,"D":.25,"AI":.20,"H":.20,"color":VN_GOLD},
    }

    c1,c2,c3=st.columns(3)
    bud=c1.slider("Ngân sách đầu tư/năm (nghìn tỷ)",300,2000,1000,100)
    T_s=c2.slider("Số năm dự báo",3,10,5,1)
    shock_yr=c3.selectbox("Năm cú sốc kinh tế",["-","2027","2028","2029"])

    def simulate_scen(cfg,B,T,shock_yr="-"):
        K,D,AI,H,A,L0=27500,20.3,86,30,0.82,53.9
        path=[]; alpha_s,beta_s,gamma_s,delta_s,theta_s=.33,.42,.10,.08,.07
        for t in range(T+1):
            L=L0*(1.01**t)
            gdp=A*(K**alpha_s)*(L**beta_s)*(D**gamma_s)*(AI**delta_s)*(H**theta_s)
            if shock_yr!="-" and t==int(shock_yr)-2025:
                gdp*=.92  # -8% shock
            path.append(gdp)
            if t<T:
                K=(1-.05)*K+B*cfg["K"]
                D=(1-.12)*D+B*cfg["D"]/100
                AI=(1-.15)*AI+B*cfg["AI"]/20
                H=H+.8*B*cfg["H"]/200-.02*H
                A=A*(1+.003*D+.002*AI+.004*H)
        return path

    years_s=list(range(2025,2025+T_s+1))
    results={sn:simulate_scen(cfg,bud,T_s,shock_yr) for sn,cfg in SCEN_CFG.items()}

    fig=go.Figure()
    for sn,cfg in SCEN_CFG.items():
        fig.add_trace(go.Scatter(x=years_s,y=results[sn],mode="lines+markers",
                                  name=sn,line=dict(color=cfg["color"],width=2.5)))
    if shock_yr!="-":
        fig.add_vline(x=int(shock_yr),line_dash="dash",line_color="#aaa",
                       annotation_text=f"Cú sốc {shock_yr}")
    fig.update_layout(height=420,yaxis_title="nghìn tỷ VND",
                       title=f"GDP dự báo 5 kịch bản (ngân sách {bud:,} nghìn tỷ/năm)",
                       plot_bgcolor="#fafafa",legend=dict(orientation="h",y=-.15))
    st.plotly_chart(fig,use_container_width=True)

    # KPI table
    kpi_rows=[]
    for sn,path in results.items():
        cagr=(path[-1]/path[0])**(1/T_s)-1
        kpi_rows.append({"Kịch bản":sn,
                          f"GDP {years_s[-1]} (nghìn tỷ)":round(path[-1],0),
                          "CAGR (%/năm)":round(cagr*100,2),
                          f"Tăng {T_s} năm (%)":round((path[-1]/path[0]-1)*100,1)})
    df_kpi=pd.DataFrame(kpi_rows)
    best_s=df_kpi.iloc[df_kpi[f"GDP {years_s[-1]} (nghìn tỷ)"].idxmax()]["Kịch bản"]
    st.dataframe(df_kpi,use_container_width=True)
    st.success(f"🏆 Kịch bản dẫn đầu: **{best_s}** → GDP {results[best_s][-1]:,.0f} nghìn tỷ")

    # Radar
    cats=["Vốn K","Số hóa D","AI","Nhân lực H"]
    fig_r=go.Figure()
    for sn,cfg in SCEN_CFG.items():
        vals=[cfg["K"],cfg["D"],cfg["AI"],cfg["H"],cfg["K"]]
        fig_r.add_trace(go.Scatterpolar(r=vals,theta=cats+[cats[0]],name=sn,fill="toself",
                                         line=dict(color=cfg["color"])))
    fig_r.update_layout(polar=dict(radialaxis=dict(visible=True,range=[0,.8])),
                         height=380,title="Cơ cấu phân bổ 5 kịch bản")
    st.plotly_chart(fig_r,use_container_width=True)

    # Risk alerts
    st.markdown('<div class="sec-title">⚠️ Cảnh báo rủi ro chính sách</div>', unsafe_allow_html=True)
    ca,cb,cc=st.columns(3)
    ca.warning("**S3 AI dẫn dắt** – Rủi ro thị trường lao động cao nếu đào tạo chưa đủ")
    cb.info("**S4 Bao trùm** – GDP tăng chậm hơn nhưng bền vững, giảm bất bình đẳng")
    cc.success("**S5 Cân bằng** – Chiến lược tối ưu dài hạn theo mô hình AIDEOM-VN")

    ai_panel("Dashboard 5 kịch bản AIDEOM-VN",
             f"Ngân sách={bud} nghìn tỷ/năm, T={T_s} năm\n"
             f"Kịch bản tốt nhất: {best_s}\n"
             f"Kết quả GDP 2030:\n{df_kpi.to_string(index=False)}",api_key)
