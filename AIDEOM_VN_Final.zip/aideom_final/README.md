# AIDEOM-VN — Dashboard 12 bài tập

## Chạy local
```bash
pip install -r requirements.txt
streamlit run app.py
```
Trình duyệt mở `http://localhost:8501`

## Deploy Streamlit Cloud (miễn phí)
1. Push thư mục lên GitHub (public repo)
2. Vào share.streamlit.io → New app → chọn `app.py`
3. Deploy → nhận link chia sẻ

## Kích hoạt AI Analyst
- Lấy Gemini API key miễn phí tại: https://aistudio.google.com/app/apikey
- Nhập vào ô **Gemini API Key** trong sidebar
- Mỗi bài có nút **▶ Phân tích với Gemini AI**
